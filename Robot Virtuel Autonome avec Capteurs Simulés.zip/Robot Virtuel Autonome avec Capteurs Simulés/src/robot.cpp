#include "robot.h"
#include <iostream>
using namespace std;

Robot::Robot(int startX, int startY, char startDir) {
    x = startX; y = startY; dir = startDir;
}

void Robot::turnLeft() {
    switch(dir){
        case 'N': dir = 'W'; break;
        case 'W': dir = 'S'; break;
        case 'S': dir = 'E'; break;
        case 'E': dir = 'N'; break;
    }
}

void Robot::turnRight() {
    switch(dir){
        case 'N': dir = 'E'; break;
        case 'E': dir = 'S'; break;
        case 'S': dir = 'W'; break;
        case 'W': dir = 'N'; break;
    }
}

int Robot::getX() { return x; }
int Robot::getY() { return y; }
char Robot::getDir() { return dir; }

void Robot::move(vector<vector<char>>& grid) {
    int newX = x, newY = y;
    switch(dir){
        case 'N': newY--; break;
        case 'S': newY++; break;
        case 'E': newX++; break;
        case 'W': newX--; break;
    }
    if(newX >=0 && newY >=0 && newX<grid[0].size() && newY<grid.size() && grid[newY][newX] != '#') {
        x = newX; y = newY;
    } else {
        turnRight(); // tourner si obstacle
    }
}

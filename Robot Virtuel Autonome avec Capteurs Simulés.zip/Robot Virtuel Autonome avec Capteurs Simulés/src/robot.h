#ifndef ROBOT_H
#define ROBOT_H

#include <vector>
using namespace std;

class Robot {
private:
    int x, y; // position
    char dir; // N, E, S, W
public:
    Robot(int startX, int startY, char startDir);
    void move(vector<vector<char>>& grid);
    void turnLeft();
    void turnRight();
    char getDir();
    int getX();
    int getY();
};

#endif
